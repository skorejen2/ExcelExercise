﻿using Microsoft.Office.Tools;
using Microsoft.Office.Tools.Ribbon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ExerciseNumberOne
{
    public partial class TestTab
    {
        private void MyRibbon_Load(object sender, RibbonUIEventArgs e)
        {
            this.TestButton.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(
    this.TestButton_Click);
        }

        private void TestButton_Click(object sender, RibbonControlEventArgs e)
        {
            Form myFrm = new Form1();
            myFrm.Show();
        }
    }

}
